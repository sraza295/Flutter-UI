import 'package:flutter/material.dart';
import 'package:flutter_app/topBarListView.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';


void main() => runApp(MyApp());
const PrimaryColor = const Color(0xFF151026);

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primaryColor: PrimaryColor,
      ),
      home: MyHomePage(title: ''),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  bool itemSelected=false;
  static final List<String> dropdownValues = [
    "Paris",
    "London",
    "USA",
    "India",
    "Japan"
  ]; //The list of values we want on the dropdown
  String currentlySelected = dropdownValues.first; //var to hold currently selected value

  //make the drop down its own widget for readability
  Widget dropdownWidget() {
    print(currentlySelected);
    return Theme(
          data: Theme.of(context).copyWith(
            canvasColor: Colors.black,
          ),
      child: DropdownButton(
        //map each value from the lIst to our dropdownMenuItem widget
        items: dropdownValues
            .map((value) => DropdownMenuItem(
          child: Text(value),
          value: value,
        ))
            .toList(),
        onChanged: (String value) {//once dropdown changes, update the state of out currentValue
          setState(() {
            currentlySelected = value;
          });
        },
        //this wont make dropdown expanded and fill the horizontal space
        isExpanded: false,
        //make default value of dropdown the first value of our list
        value: currentlySelected,
        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget bottomNavigationBar()
  {
    return BottomNavigationBar(
      backgroundColor: Colors.grey[900],// This trailing comma makes auto-formatting nicer for build methods.
      currentIndex: 0, // this will be set when a new tab is tapped
      items: [
        BottomNavigationBarItem(
          icon: CircleAvatar(
              backgroundColor: Colors.grey[900],
              child: new Icon(
                Icons.home,
                color: Colors.grey[600],
              )
          ),
          title: new Text('Account',style: TextStyle(color: Colors.grey[600], fontSize: 12, fontWeight: FontWeight.bold),),
        ),

        BottomNavigationBarItem(
          icon: CircleAvatar(
              backgroundColor: Colors.white,
              child: new Icon(
                Icons.event,
                color: Colors.grey[600],
              )
          ),
          title: new Text('Events',style: TextStyle(color: Colors.grey[600], fontWeight: FontWeight.bold),),
        ),

        BottomNavigationBarItem(
          icon: CircleAvatar(
              backgroundColor: Colors.grey[900],
              child: new Icon(
                Icons.dashboard,
                color: Colors.grey[600],
              )
          ),
          title: new Text('Dashboard',style: TextStyle(color: Colors.grey[600], fontSize: 12, fontWeight: FontWeight.bold),),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Row(
          children: <Widget>[
          SizedBox(
          width: 130, // Your width
          child: dropdownWidget(),
        ),
        ]

        ),
        backgroundColor: Colors.black,
        actions: <Widget>[
          CircleAvatar(
            backgroundColor:  Colors.grey[850],
            child: IconButton(
                color: Colors.white,
                icon: Icon(Icons.search),
                onPressed: () {
                },
              ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: CircleAvatar(
              backgroundColor:  Colors.grey[850],
              child: IconButton(
                color: Colors.white,
                icon: Icon(Icons.settings),
                onPressed: () {
                },
              ),
            ),
          ),

        ],
      ),
      body: Builder(
        builder: (context) => ListView(
            children: <Widget>[
              new Container(
                  margin: EdgeInsets.symmetric(vertical: 20.0),
                  height: 140.0,
                  child: Center(
                    child:TopBarListView(),
                  ),
                ),
              new Container(
                margin: new EdgeInsets.only(left:15.0),
                  child: new Text('Popular Events', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),)),
              new Container(
                margin: EdgeInsets.symmetric(vertical: 20.0),
                height: 400.0,
                child: Center(
                  child:horizontalListViewImages(),
                ),
              ),
              ],
          ),
        ),
      backgroundColor: Colors.black,// This trailing comma makes auto-formatting nicer for build methods.
      bottomNavigationBar: bottomNavigationBar(),
    );
  }

  bool boolAll=false;
  bool boolMusic=false;
  bool boolGuitar=false;
  bool boolNews=false;
  bool boolAirplane=false;
  bool boolYoutube=false;

  Widget horizontalListViewImages()
  {
    return new ListView(
        scrollDirection: Axis.horizontal,
        children: <Widget>[
          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(onTap: (){
            print("All");
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  color: Colors.transparent,
                  child: new Container(
                    width: 250.0,
                    height: 270,
                    decoration: new BoxDecoration(
                      image: DecorationImage(
                        image: new AssetImage('assets/images/chichen.jpeg'),
                        fit: BoxFit.fill,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(20.0)),
                    ),

                    child:  Align(
                      alignment: Alignment.bottomRight,
                      child: FractionalTranslation(
                        translation: Offset(0.0, 0.5),
                        child: CircleAvatar(
                          backgroundColor:  Colors.grey[700],
                          child: new IconButton(
                              icon: Icon(MdiIcons.heart,color: Colors.grey[500],),
                              onPressed: () {}),
                        ),
                      )
                    ),
                  ),
                ),
                Padding(padding: EdgeInsets.all(8.0)),
                Text('FRI, DEC 19TH-MON, DEC 27TH', style: TextStyle(color: Colors.deepPurple[400], fontSize: 12, fontWeight: FontWeight.bold),),
                Padding(padding: EdgeInsets.all(5.0)),
                Container(
                  width: 250,
                  child: Text(
                    "Nocturnal and unusual visit",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 5,
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
                Padding(padding: EdgeInsets.all(5.0)),
                Text("Louvre", style: TextStyle(color: Colors.grey[600], fontSize: 18, fontWeight: FontWeight.bold),),
              ],
            ),
          ),

          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(onTap: (){
            Scaffold.of(context).showSnackBar(SnackBar(
              content: Text("Chinawall"),
            ));
          },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  color: Colors.transparent,
                  child: new Container(
                    width: 250.0,
                    height: 270,
                    decoration: new BoxDecoration(
                      image: DecorationImage(
                        image: new AssetImage('assets/images/chinawall.jpeg'),
                        fit: BoxFit.fill,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(20.0)),
                    ),

                    child:  Align(
                        alignment: Alignment.bottomRight,
                        child: FractionalTranslation(
                          translation: Offset(0.0, 0.5),
                          child: CircleAvatar(
                            backgroundColor:  Colors.grey[700],
                            child: new IconButton(
                                icon: Icon(MdiIcons.heart,color: Colors.grey[500],),
                                onPressed: () {}),
                          ),
                        )
                    ),
                  ),
                ),
                Padding(padding: EdgeInsets.all(8.0)),
                Text('FRI, DEC 19TH-MON, DEC 27TH', style: TextStyle(color: Colors.deepPurple[400], fontSize: 12, fontWeight: FontWeight.bold),),
                Padding(padding: EdgeInsets.all(5.0)),
                Container(
                  width: 250,
                  child: Text(
                    "Nocturnal and unusual visit",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 5,
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
                Padding(padding: EdgeInsets.all(5.0)),
                Text("Louvre", style: TextStyle(color: Colors.grey[600], fontSize: 18, fontWeight: FontWeight.bold),),
              ],
            ),
          ),

          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(onTap: (){
            print("All");
          },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  color: Colors.transparent,
                  child: new Container(
                    width: 250.0,
                    height: 270,
                    decoration: new BoxDecoration(
                      image: DecorationImage(
                        image: new AssetImage('assets/images/chichen.jpeg'),
                        fit: BoxFit.fill,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(20.0)),
                    ),

                    child:  Align(
                        alignment: Alignment.bottomRight,
                        child: FractionalTranslation(
                          translation: Offset(0.0, 0.5),
                          child: CircleAvatar(
                            backgroundColor:  Colors.grey[700],
                            child: new IconButton(
                                icon: Icon(MdiIcons.heart,color: Colors.grey[500],),
                                onPressed: () {}),
                          ),
                        )
                    ),
                  ),
                ),
                Padding(padding: EdgeInsets.all(8.0)),
                Text('FRI, DEC 19TH-MON, DEC 27TH', style: TextStyle(color: Colors.deepPurple[400], fontSize: 12, fontWeight: FontWeight.bold),),
                Padding(padding: EdgeInsets.all(5.0)),
                Container(
                  width: 250,
                  child: Text(
                    "Nocturnal and unusual visit",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 5,
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
                Padding(padding: EdgeInsets.all(5.0)),
                Text("Louvre", style: TextStyle(color: Colors.grey[600], fontSize: 18, fontWeight: FontWeight.bold),),
              ],
            ),
          ),

          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(onTap: (){
            print("All");
          },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  color: Colors.transparent,
                  child: new Container(
                    width: 250.0,
                    height: 270,
                    decoration: new BoxDecoration(
                      image: DecorationImage(
                        image: new AssetImage('assets/images/chichen.jpeg'),
                        fit: BoxFit.fill,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(20.0)),
                    ),

                    child:  Align(
                        alignment: Alignment.bottomRight,
                        child: FractionalTranslation(
                          translation: Offset(0.0, 0.5),
                          child: CircleAvatar(
                            backgroundColor:  Colors.grey[700],
                            child: new IconButton(
                                icon: Icon(MdiIcons.heart,color: Colors.grey[500],),
                                onPressed: () {}),
                          ),
                        )
                    ),
                  ),
                ),
                Padding(padding: EdgeInsets.all(8.0)),
                Text('FRI, DEC 19TH-MON, DEC 27TH', style: TextStyle(color: Colors.deepPurple[400], fontSize: 12, fontWeight: FontWeight.bold),),
                Padding(padding: EdgeInsets.all(5.0)),
                Container(
                  width: 250,
                  child: Text(
                    "Nocturnal and unusual visit",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 5,
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
                Padding(padding: EdgeInsets.all(5.0)),
                Text("Louvre", style: TextStyle(color: Colors.grey[600], fontSize: 18, fontWeight: FontWeight.bold),),
              ],
            ),
          ),

          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(onTap: (){
            print("All");
          },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  color: Colors.transparent,
                  child: new Container(
                    width: 250.0,
                    height: 270,
                    decoration: new BoxDecoration(
                      image: DecorationImage(
                        image: new AssetImage('assets/images/chichen.jpeg'),
                        fit: BoxFit.fill,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(20.0)),
                    ),

                    child:  Align(
                        alignment: Alignment.bottomRight,
                        child: FractionalTranslation(
                          translation: Offset(0.0, 0.5),
                          child: CircleAvatar(
                            backgroundColor:  Colors.grey[700],
                            child: new IconButton(
                                icon: Icon(MdiIcons.heart,color: Colors.grey[500],),
                                onPressed: () {}),
                          ),
                        )
                    ),
                  ),
                ),
                Padding(padding: EdgeInsets.all(8.0)),
                Text('FRI, DEC 19TH-MON, DEC 27TH', style: TextStyle(color: Colors.deepPurple[400], fontSize: 12, fontWeight: FontWeight.bold),),
                Padding(padding: EdgeInsets.all(5.0)),
                Container(
                  width: 250,
                  child: Text(
                    "Nocturnal and unusual visit",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 5,
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
                Padding(padding: EdgeInsets.all(5.0)),
                Text("Louvre", style: TextStyle(color: Colors.grey[600], fontSize: 18, fontWeight: FontWeight.bold),),
              ],
            ),
          ),
        ]
    );
  }
}
