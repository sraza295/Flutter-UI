import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

class TopBarListView extends StatefulWidget
{

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return TopBarListViewState();
  }

}

class TopBarListViewState extends State<TopBarListView>
{
  bool boolAll=false;
  bool boolMusic=false;
  bool boolGuitar=false;
  bool boolNews=false;
  bool boolAirplane=false;
  bool boolYoutube=false;

  @override
  Widget build(BuildContext context)
  {
    return new ListView(
        scrollDirection: Axis.horizontal,
        children: <Widget>[
          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(
            onTap: (){
              if(boolAll)
                boolAll=false;
              else
                boolAll=true;
              setState(() {
              });
              Scaffold.of(context).showSnackBar(SnackBar(
                content: Text("All"),
              ));
            },
            child: new Container(
              width: 70.0,
              color: Colors.transparent,
              child: new Container(
                decoration: boolAll?new BoxDecoration(
                    color: Colors.deepPurpleAccent[200],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0))):new BoxDecoration(
                    color: Colors.grey[600],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0)
                    )
                ),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: boolAll?CircleAvatar(
                        backgroundColor:  Colors.deepPurpleAccent[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(Icons.wb_sunny),
                          onPressed: () {

                          },
                        ),
                      ):CircleAvatar(
                        backgroundColor:  Colors.grey[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(Icons.wb_sunny),
                          onPressed: () {

                          },
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                    ),
                    new Text('All', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),),
                  ],
                ),
              ),
            ),
          ),

          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(onTap: (){
            if(boolMusic)
              boolMusic=false;
            else
              boolMusic=true;
            setState(() {
            });
            Scaffold.of(context).showSnackBar(SnackBar(
              content: Text("Music"),
            ));
          },
            child: Container(
              width: 70.0,
              color: Colors.transparent,
              child: new Container(
                decoration: boolMusic?new BoxDecoration(
                    color: Colors.deepPurpleAccent[200],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0))):new BoxDecoration(
                    color: Colors.grey[600],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0)
                    )
                ),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child:boolMusic?CircleAvatar(
                        backgroundColor:  Colors.deepPurpleAccent[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(Icons.music_note),
                          onPressed: () {

                          },
                        ),
                      ):CircleAvatar(
                        backgroundColor:  Colors.grey[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(Icons.music_note),
                          onPressed: () {

                          },
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                    ),
                    new Text('Music', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),),
                  ],
                ),
              ),
            ),
          ),

          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(onTap: (){
            if(boolGuitar)
              boolGuitar=false;
            else
              boolGuitar=true;
            setState(() {
            });
            Scaffold.of(context).showSnackBar(SnackBar(
              content: Text("Guitar"),
            ));
          },
            child: Container(
              width: 70.0,
              color: Colors.transparent,
              child: new Container(
                decoration: boolGuitar?new BoxDecoration(
                    color: Colors.deepPurpleAccent[200],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0))):new BoxDecoration(
                    color: Colors.grey[600],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0)
                    )
                ),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: boolGuitar?CircleAvatar(
                        backgroundColor:  Colors.deepPurpleAccent[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(MdiIcons.guitarElectric),
                          onPressed: () {

                          },
                        ),
                      ):CircleAvatar(
                        backgroundColor:  Colors.grey[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(MdiIcons.guitarElectric),
                          onPressed: () {

                          },
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                    ),
                    new Text('Guitar', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),),
                  ],
                ),
              ),
            ),
          ),

          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(onTap: (){
            if(boolNews)
              boolNews=false;
            else
              boolNews=true;
            setState(() {
            });
            Scaffold.of(context).showSnackBar(SnackBar(
              content: Text("News"),
            ));
          },
            child: Container(
              width: 70.0,
              color: Colors.transparent,
              child: new Container(
                decoration: boolNews?new BoxDecoration(
                    color: Colors.deepPurpleAccent[200],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0))):new BoxDecoration(
                    color: Colors.grey[600],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0)
                    )
                ),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: boolNews?CircleAvatar(
                        backgroundColor:  Colors.deepPurpleAccent[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(MdiIcons.newspaper),
                          onPressed: () {

                          },
                        ),
                      ):CircleAvatar(
                        backgroundColor:  Colors.grey[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(MdiIcons.newspaper),
                          onPressed: () {

                          },
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                    ),
                    new Text('News', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),),
                  ],
                ),
              ),
            ),
          ),

          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(onTap: (){
            if(boolAirplane)
              boolAirplane=false;
            else
              boolAirplane=true;
            setState(() {
            });
            Scaffold.of(context).showSnackBar(SnackBar(
              content: Text("Airplane"),
            ));
          },
            child: Container(
              width: 70.0,
              color: Colors.transparent,
              child: new Container(
                decoration: boolAirplane?new BoxDecoration(
                    color: Colors.deepPurpleAccent[200],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0))):new BoxDecoration(
                    color: Colors.grey[600],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0)
                    )
                ),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: boolAirplane?CircleAvatar(
                        backgroundColor:  Colors.deepPurpleAccent[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(MdiIcons.airplane),
                          onPressed: () {

                          },
                        ),
                      ):CircleAvatar(
                        backgroundColor:  Colors.grey[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(MdiIcons.airplane),
                          onPressed: () {

                          },
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                    ),
                    new Text('Airplane', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),),
                  ],
                ),
              ),
            ),
          ),

          Padding(padding: EdgeInsets.all(8.0)),
          InkWell(onTap: (){
            if(boolYoutube)
              boolYoutube=false;
            else
              boolYoutube=true;
            setState(() {
            });
            Scaffold.of(context).showSnackBar(SnackBar(
              content: Text("Youtube"),
            ));
          },
            child: Container(
              width: 70.0,
              color: Colors.transparent,
              child: new Container(
                decoration: boolYoutube?new BoxDecoration(
                    color: Colors.deepPurpleAccent[200],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0))):new BoxDecoration(
                    color: Colors.grey[600],
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(40.0),
                        topRight: const Radius.circular(40.0),
                        bottomLeft: const Radius.circular(40.0),
                        bottomRight: const Radius.circular(40.0)
                    )
                ),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: boolYoutube?CircleAvatar(
                        backgroundColor:  Colors.deepPurpleAccent[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(MdiIcons.youtube),
                          onPressed: () {

                          },
                        ),
                      ):CircleAvatar(
                        backgroundColor:  Colors.grey[700],
                        child: IconButton(
                          color: Colors.yellow,
                          icon: Icon(MdiIcons.youtube),
                          onPressed: () {

                          },
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                    ),
                    new Text('Youtube', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),),
                  ],
                ),
              ),
            ),
          ),
          Padding(padding: EdgeInsets.all(8.0)),

        ]
    );
  }
}